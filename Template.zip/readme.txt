Template readme
---------------

This folder contains a template project you can use as your starting point for group project.

One team member does the following
1) Copy the zip file to the directory where you want to have the project
2) Extract the zip file in that folder
3) Import the the two TEAM_* projects into your workspace
4) Set the Processor Expert configuration to either V1 or V2 robot
5) Generate, build and debug both projects to be sure they work on the hardware
6) Commit and push the projects plus the TEAM_Common Folder to your team git repository.
   Make sure you only commit what is necessary!

The other team member does the following:
1) pulls the team projects and folders on his machine
2) if everything is configured correctly, he can generate code, build and debug the two projects as well.

Good luck :-)